# HEADER 1 #
# HEADER 2 #

* Clone this repository
* Create Branch
* Create Subfolder
* Add README file

<p>The biggest advantage of Auto Scaling is the dynamic scaling
of resources based on the demand. There is no limit to the number of servers
you can scale up to. You can scale up from two servers to hundreds or thousands
or tens of thousands of servers almost instantly. Using Auto Scaling you can
make sure that your application always performs optimally and gets additional
horsepower in terms of CPU and other resources whenever needed. You are able
to provision them in real time.</p>