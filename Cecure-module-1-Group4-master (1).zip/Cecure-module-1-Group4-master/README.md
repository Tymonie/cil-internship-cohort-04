# Cecure Intelligence limited 
[We build modern digital products with experienced development teams.](https://cecureintel.com/)


# Module 1 practicals for Cohort-4
This is to facilitate the broad understanding of the various domains.
These domains are 
* Data Engineering
* business analysis
* Cloud Engineering
* Front-end developer

<p> Paragraph ---- Feel free to correct my errors and add more contents 😉. <p/>
